 
  <form action="" method="post" class="main-form full">
      <!--package Block Start -->
      <section class="ptb-100 booking-detail">
        <div class="container">
          <div class="row">
            <div class="col-md-6 offset-md-3">
              <div class="sidebar-block sidebar-block-1 mb-md-30">
                <div class="box-shadow radius-5px p-25 p-xs-15">
                  <div class="sidebar-box listing-box"> <span class="opener plus"></span>
                    <div class="sidebar-title">
					<?php  $cname = $booking[0]->hotel_id;
				$sqll= "SELECT * FROM hotel WHERE id='$cname'"; 
                $sql = $this->db->query($sqll);
                $query= $sql->result();
                 if(isset($query[0]->id)) {
                  //echo $query[0]->id;
                   }
						   ?> 
                      <h3><span>Invoice No. HTA0<?php echo $booking[0]->id;?><?php echo $booking[0]->hotel_id;?></span></h3>
                    </div>
                    <div class="sidebar-contant pt-4" style="display:block">
                      <div class="main-form booking-detail-form">
                        
                        <div class="packages-details packages-booking-detail pt-25">
						<div class="row">
						<div class="col-lg-4">
						<div class="booking-img ">
						
						
  <a href="#"><img witdh="100%" src="<?php echo base_url();?>/upload_images/<?php echo $query[0]->thumb_image;?>"></a>
                        </div>
                        </div>
							<div class="col-lg-8">
                          <div class="d-flex  justify-content-between">
                            <div class="mb-2">
                              <h4 class="mb-0"><span class="title"><?php echo $query[0]->title?></span></h4>
                              <p class="tour-meta m-0"><?php echo $query[0]->address?></p>
                            </div>
                            
                          </div>
						  
						    <div class="rating-summary-block">
                            <div class="rating-result" title="70%"> <span style="width:<?php echo $query[0]->star*20;?>%"></span> </div>
                            <span class="label-review"><?php echo $query[0]->star;?> Star</span>
                          </div>
						  <div class="row">
						  	<div class="col-lg-6">
						<div class="w-auto d-block mb-n1">
                                  <span class="icon"><i class="far fa-calendar-alt"></i></span><span class="list-title">Check in</span>
                                </div><?php echo $booking[0]->check_in;?>
							       </div>
							   
							   	<div class="col-lg-6">
								
							 <div class="w-auto d-block mb-n1">
                                 <span class="icon"><i class="far fa-calendar-alt"></i></span><span class="list-title">Check out</span>
                                </div><?php echo $booking[0]->check_out;?>
								 
							   </div>
							   </div>
                          </div>
						  
                          </div>
						  
 
                          <div class="list-items mt-20">
						  
						  	
							   <hr>
							   
							   
							  
				 
						  
                            <ul class=" list-group list-group-horizontal">
							
							  <li class="list-group-item">
                                <div class="w-auto d-block mb-n1">
                                 <span class="icon"><i class="far fas fa-home"></i></span><span class="list-title">Room</span>
                                </div><?php echo $booking[0]->rooms;?>
                              </li>
							  
                             
							 
							  
							   <li class="list-group-item">
                                <div class="w-auto d-block mb-n1">
                                 <span class="icon"><i class="fas far fa-users"></i></span><span class="list-title">Adult</span>
                                </div><?php echo $booking[0]->adults;?>
								 
                              </li>
							  
							   <li class="list-group-item">
                                <div class="w-auto d-block mb-n1">
                                 <span class="icon"><i class="fas far fa-child"></i></span><span class="list-title">Child</span>
                                </div><?php echo $booking[0]->children;?>
								 
                              </li>
							  
							   
							  
                              
                            </ul>
                          </div>
                        </div>
                        <div class="order-details mt-30 mt-xs-15">
                          <h4 class="title">Order Details</h4>
                          <div class="Tour-total-table commun-table">
                            <div class="table-responsive">
							
							
							<table class="table">
                                <tbody>
                                  
                                  <tr>
                                    <td class="px-0">Customer Name</td>
                                    <td>
                                        <span class="benefits"><?php echo $booking[0]->customer;?>
								  Rooms</span> 
                                    </td>
                                  </tr>
                                  <tr>
                                    <td class="px-0">Phone</td>
                                    <td>
                                        <span class="person"><?php echo $booking[0]->phone;?>  </span> 
                                     </td>
                                  </tr>
								  
								  
								    <tr>
                                    <td class="px-0">Email</td>
                                    <td>
                                        <span class="person"><?php echo $booking[0]->email;?> </span> 
                                     </td>
                                  </tr>
								  
								  
                                 <tr>
                                    <td class="px-0">Address</td>
                                    <td>
                                        <span class="person"><?php echo $booking[0]->customer_address;?>
								  infants</span> 
                                    </td>
                                  </tr>
                                
                                </tbody>
                              </table>
							
                       
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="sidebar-box"> <span class="opener plus"></span>
                    <div class="sidebar-title">
                      <h3><span>Need Help</span></h3>
                    </div>
                    <div class="sidebar-contant pt-3">
                      <div class="support-service p-25 p-xs-15">
                        <span><i class="fas fa-phone-alt"></i></span>
                        <h3>+91-8630658592</h3>
                        <p class="m-0">Call Free & 24/7 Available</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12 order-lg-12">
             
              <div class="payment-method check-mark-tab mt-60">
               
                <div class="tab-content" id="tab_content">
                     <div class="col-12 ">
                          <div class="Submit-btn text-center">
                            <a href="<?php echo base_url();?>"    class="btn btn-color">
                              <span>Back To Home</span>
                            </a>
                          </div>
                        </div>
            
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--package Block End -->
	     </form>
﻿       <section class="home-banner banner-wrapper2">
        <div class="banner">
        <div class="main-banner owl-carousel ">
            <div class="item">
              <div class="banner-1"> <img src ="<?php echo base_url();?>front_assets/images/banner1.jpg" alt="TravelRide">
                <div class="banner-detail text-center">
                  <div class="container">
                    <div class="row align-items-center">
                      <div class="col-12">
                        <div class="banner-detail-inner slider-animation animated-1"> 
                          <div class="slogan">84 KOSH BRIJ YATRA</div>
                          <h1 class="banner-title">Find Your Perfect Trip</h1>
                          <p class="">Visiting every shrine in Mathura-Vrindavan 84 Kosh Yatra</p>
                          <a class="btn btn-color mt-2 mt-sm-0" href="#"><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 384 512"><path d="M172.3 501.7C27 291 0 269.4 0 192 0 86 86 0 192 0s192 86 192 192c0 77.4-27 99-172.3 309.7-9.5 13.7-29.9 13.7-39.4 0h0zM192 272c44.2 0 80-35.8 80-80s-35.8-80-80-80-80 35.8-80 80 35.8 80 80 80z" fill="#fff"></path></svg> View Our Place</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="banner-1"> <img src ="<?php echo base_url();?>front_assets/images/banner2.jpg" alt="TravelRide">
                <div class="banner-detail text-center">
                  <div class="container">
                    <div class="row align-items-center">
                      <div class="col-12">
                        <div class="banner-detail-inner slider-animation animated-1"> 
                          <div class="slogan">The best tour experience</div>
                          <h1 class="banner-title">Find Your Perfect Trip</h1>
                          <p class="">Curabitur nunc erat, consequat in erat ut, congue bibendum nulla. Suspendisse id pharetra lacus, et hendrerit mi quis leo elementum.</p>
                          <a class="btn btn-color mt-2 mt-sm-0" href="#"><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 384 512"><path d="M172.3 501.7C27 291 0 269.4 0 192 0 86 86 0 192 0s192 86 192 192c0 77.4-27 99-172.3 309.7-9.5 13.7-29.9 13.7-39.4 0h0zM192 272c44.2 0 80-35.8 80-80s-35.8-80-80-80-80 35.8-80 80 35.8 80 80 80z" fill="#fff"></path></svg> View Our Tours</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="tour-search tour-wrapper mt-40">
            <div class=" main-form tour-search-detail">
              <div class="container">
                <ul class="nav nav-tabs" id="tab" role="tablist">
				  <li class="nav-item">
                    <a class="nav-link btn" id="hotel_tab" data-toggle="tab" href="#hotel" role="tab" aria-controls="hotel" aria-selected="false">Hotels</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link btn active" id="tours_tab" data-toggle="tab" href="#tours" role="tab" aria-controls="tours" aria-selected="true">Tours</a>
                  </li>
                
                   

                  <li class="nav-item">
                    <a class="nav-link btn"   href="https://jsdl.in/DT-99MZJJWJNB6"  >Cars</a>
                  </li>
                </ul>
                <div class="search-form-wrapper">
                  <div class="tab-content" id="tab_content">
                    <div class="tab-pane fade show active" id="tours" role="tabpanel" aria-labelledby="tours_tab">
                      <form class="main-form" action="#">
                        <div class="row align-items-end justify-content-center">
                          <div class="form-group col-xl-3 col-md-6 col-12">
                            <div class="input-inner mb-3 mb-xl-0">
                              <label>Your Destinationss</label>
                              <div class="input-box">
                                <div class="input-icon">
                                  <span><i class="fas fa-map-marker-alt"></i></span>
                                </div>
                                <input id="tour-destinationss" class="form-control" type="text" required="" placeholder="Enter a destination">
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-2 col-md-3 col-sm-6">
                            <div class="input-inner mb-3 mb-xl-0">
                              <label>Travel Date</label>
                              <div class="input-box">
                                <div class="input-icon">
                                  <span><i class="far fa-calendar-alt"></i></span>
                                </div>
                                <input id="tour-start-date" class="form-control datepicker datepick" type="text" required="" placeholder="MM/DD/YY">
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-2 col-md-3 col-sm-6">
                            <div class="input-inner mb-3 mb-xl-0">
                              <label>Return Date</label>
                              <div class="input-box">
                                <div class="input-icon">
                                  <span><i class="far fa-calendar-alt"></i></span>
                                </div>
                                <input id="tour-start-end" class="form-control datepicker datepick" type="text" required="" placeholder="MM/DD/YY">
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-3 col-md-8 col-sm-12">
                            <div class="row">
                              <div class="col-6">
                                <div class="input-inner mb-3 mb-md-0">
                                  <label>Adults</label>
                                  <select class="select" name="adults">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-6">
                                <div class="input-inner mb-3 mb-md-0">
                                  <label>Children</label>
                                  <select class="select" name="children">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-2 col-md-4 col-sm-6 col-12">
                            <div class="search-btn">
                              <button name="search" type="submit" class="btn btn-color w-100">
                                <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 17 17"><path d="M11.35 1.94a6.67 6.67 0 0 0-9.41 0 6.67 6.67 0 0 0 0 9.41c2.31 2.31 5.91 2.56 8.5.75.05.26.18.5.38.7l3.78 3.78c.55.55 1.44.55 1.99 0s.55-1.44 0-1.99l-3.78-3.78c-.2-.2-.45-.33-.7-.38 1.8-2.58 1.55-6.17-.76-8.49zm-1.19 8.22c-1.94 1.94-5.09 1.94-7.02 0a4.98 4.98 0 0 1 0-7.02c1.94-1.94 5.09-1.94 7.02 0s1.94 5.08 0 7.02z" fill-rule="evenodd" fill="#fff"></path></svg> Search Now
                              </button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                    <div class="tab-pane fade" id="hotel" role="tabpanel" aria-labelledby="hotel_tab">
                      <form class="main-form" action="#">
                        <div class="row align-items-end justify-content-center">
                          <div class="form-group col-xl-3 col-md-6 col-12">
                            <div class="input-inner mb-3 mb-xl-0">
                              <label>Search for Hotels</label>
                              <div class="input-box">
                                <div class="input-icon">
                                  <span><i class="fas fa-map-marker-alt"></i></span>
                                </div>
                                <input id="hotel-destinationss" class="form-control" type="text" required="" placeholder="Search for Hotels">
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-2 col-md-3 col-sm-6">
                            <div class="input-inner mb-3 mb-xl-0">
                              <label>Check In</label>
                              <div class="input-box">
                                <div class="input-icon">
                                  <span><i class="far fa-calendar-alt"></i></span>
                                </div>
                                <input id="hotel-start-date" class="form-control datepicker datepick" type="text" required="" placeholder="MM/DD/YY">
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-2 col-md-3 col-sm-6">
                            <div class="input-inner mb-3 mb-xl-0">
                              <label>Check Out</label>
                              <div class="input-box">
                                <div class="input-icon">
                                  <span><i class="far fa-calendar-alt"></i></span>
                                </div>
                                <input id="hotel-start-end" class="form-control datepicker datepick" type="text" required="" placeholder="MM/DD/YY">
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-3 col-md-8 col-sm-12">
                            <div class="row">
                              <div class="col-4">
                                <div class="input-inner mb-3 mb-md-0">
                                  <label>Adults</label>
                                  <select class="select" name="adults">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="input-inner mb-3 mb-md-0">
                                  <label>Children</label>
                                  <select class="select" name="children">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="input-inner mb-3 mb-md-0">
                                  <label>Rooms</label>
                                  <select class="select" name="Rooms">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="form-group col-xl-2 col-md-4 col-sm-6 col-12">
                            <div class="search-btn">
                              <button name="search" type="submit" class="btn btn-color w-100">
                                <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 17 17"><path d="M11.35 1.94a6.67 6.67 0 0 0-9.41 0 6.67 6.67 0 0 0 0 9.41c2.31 2.31 5.91 2.56 8.5.75.05.26.18.5.38.7l3.78 3.78c.55.55 1.44.55 1.99 0s.55-1.44 0-1.99l-3.78-3.78c-.2-.2-.45-.33-.7-.38 1.8-2.58 1.55-6.17-.76-8.49zm-1.19 8.22c-1.94 1.94-5.09 1.94-7.02 0a4.98 4.98 0 0 1 0-7.02c1.94-1.94 5.09-1.94 7.02 0s1.94 5.08 0 7.02z" fill-rule="evenodd" fill="#fff"></path></svg> Search Now
                              </button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                   </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- BANNER END --> 

      <!-- CONTAIN START -->

      <!--  Categorie Start  -->
      <div class="ptb-100">
        <div class="container">
          <div class="row no-gutters">
            <div class="col-12">
              <div class="heading-part text-center mb-30 mb-sm-20">
                <h2 class="main_title heading mb-15">THE <span>HOLY TRIP ADVISOR</span> </h2>
                <p class="heading-des">All placed which is included Hotel and Tours</p>
              </div>
            </div>
          </div>
          <div class="categorie categorie_2">
            <div class="row">
           <?php foreach($location as $view) { ?>
              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-6 mb-30 the-world">
                <div class="categorie-box card"> 
                  <div class="card-body p-0"> 
                    <div class="cat-item text-center"> 
                      <div class="cat-img"> 
                        <img src ="<?php echo base_url();?>upload_images/<?php echo $view->image;?>" alt="<?php echo $view->city;?>" class=""> 
                      </div> 
                      <div class="cat-desc"> 
                        <h5 class="mb-0 mt-3"><?php echo $view->city;?></h5> 
                        <a href="#" class="btn btn-color"> <b>12</b> Places</a> 
                      </div> 
                    </div> 
                  </div> 
                </div>
              </div>
			  
		   <?php } ?>
             <div class="text-center col-12">
                <a class="btn-color btn text-center" id="loadMore-best">Show More</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--  Categorie Block End  -->
     <section class="pb-100">
        <div class="container">
          <div class="row no-gutters">
            <div class="col-12">
                <div class="heading-part text-center mb-30 mb-sm-20">
                <h2 class="main_title heading mb-15">Popular <span>Hotel</span> And <span>Resort</span></h2>
                <p class="heading-des">Top and most rated hotel of Holy Trip Advisor</p>
              </div>
            </div>
          </div>
          <div class="row">
            <div id="packages-part" class="packages-part owl-carousel">
                  <?php foreach($hotel as $view) { ?>
			  <div class="item"> 
                <div class="card packages-box box-shadow overflow-hidden">
                  <div class="package-img position-relative">
                    <a href="#">
<img alt="TravelRide" src ="<?php echo base_url();?>/upload_images/<?php echo $view->thumb_image;?>" style="height:300px;">
                      <div class="effect"></div>
                    </a>
                   <!-- <div class="price-box position-absolute mt-2"> 
                      <div class=" d-flex align-items-center">
                        <div class="price mb-0">$89</div> 
                        <div class="price-text mb-0 ml-2">/ Night</div> 
                      </div>
                    </div>-->
                  </div>
                  <div class="card-body p-25 p-xs-15">
                    <div class="packages-details">
                      <h4><a href="#" class="title"><?php echo $view->title;?>, 
					  <?php  $cname = $view->location_id;
								$sqll= "SELECT * FROM location WHERE id='$cname'"; 
                                            $sql = $this->db->query($sqll);
                                            $query= $sql->result();
                                            if(isset($query[0]->city)) {
                                                echo $query[0]->city;
                                            }
						   ?></a></h4>
                      <div class="mt-2">  
                        <ul>
                          <li>
                            <div class="places"><span class="icon"><i class="fas fa-map-marker-alt"></i></span> 
							<?php echo $view->address;?> </div>
                          </li>
                        </ul> 
                      </div>
                      <p class="my-2"><?php echo substr(strip_tags($view->overview),0, 50);?> </p>
                      <div class="rating-summary-block">
                        <div class="rating-result" title="70%"> <span style="width:<?php echo $view->star*20;?>%"></span> </div>
                        <span class="label-review"><?php echo $view->star;?> Rating</span>
                      </div>
                      <div class="packages-btn mt-30 mt-xs-20">
                        <a class="btn btn-color mr-3" href="<?php echo base_url();?>home/hotel_detail/<?php echo $view->id;?>">Book Now</a>
                        <a class="btn btn-light" href="<?php echo base_url();?>home/hotel_detail/<?php echo $view->id;?>">View Detail</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            
			    <?php } ?>
			
			
			</div>
          </div>
        </div>
      </section>
    

      <!-- parallax Start -->
      <section>
        <div class="parallax-banner ptb-100">
          <div class="container">
            <div class="row">
              <div class="col-xl-8 offset-xl-2 ptb-70 client-box">
                <div class="parallax-delail text-center color-white">
                  <div class="parallax-subtitle">From <span>$960</span></div>
                  <div class="parallax-title">Princess World Cruise vacation</div>
                  <div class="parallax-des mtb-20">
                    <ul>
                      <li>
                        <div class="places"><span><i class="fas fa-map-marker-alt"></i></span> America</div>
                      </li>
                      <li>
                        <div class="places"><span><i class="far fa-calendar-alt"></i></span> July 19th</div>
                      </li>
                    </ul>
                  </div>
                  <div class="rating-summary-block mb-10">
                    <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                    <span class="label-review">10 Reviews</span>
                  </div>
                  <p>Curabitur nunc erat, consequat in erat ut, congue bibendum nulla. Suspendisse id pharetra lacus, et hendrerit mi quis leo elementum.</p>
                  <a class="btn btn-color mt-2 mt-sm-3" href="#"><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 384 512"><path d="M172.3 501.7C27 291 0 269.4 0 192 0 86 86 0 192 0s192 86 192 192c0 77.4-27 99-172.3 309.7-9.5 13.7-29.9 13.7-39.4 0h0zM192 272c44.2 0 80-35.8 80-80s-35.8-80-80-80-80 35.8-80 80 35.8 80 80 80z" fill="#fff"></path></svg> View Our Tours</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- parallax End -->

      <!-- Our Destinations Start  
      <section class="pt-100 ">
        <div class="destinations-part mb_-30 text-center">
          <div class="container">
            <div class="row no-gutters">
              <div class="col-12">
                <div class="heading-part text-center mb-30 mb-sm-20">
                  <h2 class="main_title heading mb-15">Destination <span>Wedding &  Events</span></h2>
                  <p class="heading-des">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
              </div>
            </div>
            <ul class="nav nav-tabs text-center  mb-30" id="tab3" role="tablist">
              <li class="nav-item">
                <a class="nav-link btn active" id="national_tour_tab" data-toggle="tab" href="#national_tour" role="tab" aria-controls="national_tour" aria-selected="true">National Tour</a>
              </li>
              <li class="nav-item">
                <a class="nav-link btn" id="international_tour_tab" data-toggle="tab" href="#international_tour" role="tab" aria-controls="international_tour" aria-selected="false">International Tour</a>
              </li>
            </ul>
            <div class="tab-content" id="tab_content3">
              <div class="tab-pane fade show active" id="national_tour" role="tabpanel" aria-labelledby="national_tour_tab">
                <div class="row">
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/national_tour_1.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Weekend Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Weekend Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/national_tour_2.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Holiday Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Holiday Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/national_tour_3.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Historical Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Historical Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/national_tour_4.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Family Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Family Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/national_tour_5.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Beach Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Beach Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/national_tour_6.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Wildlife Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Wildlife Tour</h4>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="international_tour" role="tabpanel" aria-labelledby="international_tour_tab">
                <div class="row">
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/destinations_img_1.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Europe</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Europe</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/destinations_img_2.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Thailand</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Thailand</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/destinations_img_3.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Greece</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Greece</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/destinations_img_4.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Asia</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Asia</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/destinations_img_5.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">Netherlands</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">Netherlands</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12 mb-30">
                    <div class="desti-item"> 
                      <img src ="<?php echo base_url();?>front_assets/images/destinations_img_6.jpg" alt="TravelRide">
                      <div class="desti-detail-hover color-white">
                        <div class="detail-inner-hover">
                          <h4 class="title color-white">United States</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3 mb-1 mb-md-2">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                          <p class="dec">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                          <div class="packages-btn mt-30 mt-md-15">
                            <a class="btn btn-color" href="tour_detail.html">View Detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="desti-detail">
                        <div class="detail-inner">
                          <h4 class="title color-white">United States</h4>
                          <div class="tour-info"> 
                            <ul>
                              <li>
                                <div class="days">4 Days, 5 Nights Start Froms</div>
                              </li>
                            </ul>
                          </div>
                          <hr>
                          <div class="d-flex align-items-center justify-content-between mt-2 mt-md-3">
                            <div class="price-box "> 
                              <div class="price color-white mb-0"><span>Only </span>$235</div>
                            </div>
                            <div class="rating-summary-block m-0">
                              <div class="rating-result" title="70%"> <span style="width:66%"></span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Popular Tour Packages End -->

  <!-- Popular Tour Packages Start -->
      <section class="ptb-100">
        <div class="container">
          <div class="row no-gutters">
            <div class="col-12">
              <div class="heading-part text-center mb-30 mb-sm-20">
                <h2 class="main_title heading mb-15">Popular Tour <span>Packages</span></h2>
                <p class="heading-des">Holy Trip Advisor Best popular tour, we recommended</p>
              </div>
            </div>
          </div>
          <div class="row">
            <div id="packages-part" class="packages-part owl-carousel">
              
			   <?php foreach($tour as $view) { ?>
			  <div class="item"> 
                <div class="card packages-box box-shadow overflow-hidden">
                  <div class="package-img">
                    <a href="<?php echo base_url();?>home/tour_detail/<?php echo $view->id;?>">
<img alt="TravelRide" src ="<?php echo base_url();?>/upload_images/<?php echo $view->thumb_image;?>" style="height:300px;">                      <div class="effect"></div>
                    </a>
                  </div>
                  <div class="card-body p-25 p-xs-15">
                    <div class="packages-details">
                      <h4><a href="<?php echo base_url();?>home/tour_detail/<?php echo $view->id;?>" class="title"><?php echo $view->title;?></a></h4>
                      <div class="rating-summary-block">
                        <div class="rating-result" title="70%"> <span style="width:<?php echo $view->star*20;?>%"></span> </div>
                        <span class="label-review"><?php echo $view->star;?> Rating</span>
                      </div>
                      <div class="d-flex align-items-center mt-2 mt-sm-4"> 
                        <div class="tour-info"> 
                          <ul>
                            <li>
        <div class="days"><span><i class="far fa-clock"></i></span> <?php echo $view->duration;?> |  <?php echo $view->tourtype;?></div>
							   
                            </li>
                            <li>
                              <div class="places"><span><i class="fas fa-map-marker-alt"></i></span><?php  $cname = $view->location_id;
								$sqll= "SELECT * FROM location WHERE id='$cname'"; 
                                            $sql = $this->db->query($sqll);
                                            $query= $sql->result();
                                            if(isset($query[0]->city)) {
                                                echo $query[0]->city;
                                            }
						   ?></div>
                            </li>
                          </ul>
                        </div> 
                        <!--<div class="price-box ml-auto mt-0 border-left pl-2 pl-lg-5 pl-md-3 pl-sm-5 text-center"> 
                          <div class="price-text mb-1">Price</div> 
                          <div class="price mb-0">$750</div> 
                        </div>-->
                      </div>
                      <div class="packages-btn mt-30 mt-xs-20">
                        <a class="btn btn-color mr-3" href="<?php echo base_url();?>home/tour_detail/<?php echo $view->id;?>">Book Now</a>
                        <a class="btn btn-light" href="<?php echo base_url();?>home/tour_detail/<?php echo $view->id;?>">View Detail</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
			  
			   <?php } ?>
                </div>
          </div>
        </div>
      </section>
      <!-- Popular Tour Packages End -->

      <!-- counter Start -->
      <section class="counter-area-home">
        <div class="counter-area number-counters ptb-100">
          <div class="container">
            <div class="row">
              <div class="col-lg-3 col-md-6 col-12 mb-md-30 text-center"> 
                <div class="counters-item">
                  <div class="counter-icon clients">
                    <img alt="TravelRide" src ="<?php echo base_url();?>front_assets/images/counter_icon_1.png">
                  </div>
                  <div class="count-text"><span class="counter">13323</span><span>+</span></div>
                  <div class="info-text">Happy Clients</div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-12 mb-md-30 text-center"> 
                <div class="counters-item">
                  <div class="counter-icon project">
                    <img alt="TravelRide" src ="<?php echo base_url();?>front_assets/images/counter_icon_2.png">
                  </div>
                  <div class="count-text"><span class="counter">14520</span><span>+</span></div>
                  <div class="info-text">Amazing Tours</div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-12 mb-sm-30 text-center"> 
                <div class="counters-item">
                  <div class="counter-icon advisors">
                    <img alt="TravelRide" src ="<?php echo base_url();?>front_assets/images/counter_icon_3.png">
                  </div>
                  <div class="count-text"><span class="counter">11450</span><span>+</span></div>
                  <div class="info-text">Customer Review</div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-12 text-center"> 
                <div class="counters-item">
                  <div class="counter-icon achived">
                    <img alt="TravelRide" src ="<?php echo base_url();?>front_assets/images/counter_icon_4.png">
                  </div>
                  <div class="count-text"><span class="counter">15250</span><span>+</span></div>
                  <div class="info-text">Tour Booking</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- counter End -->

      

      <!-- Our Latest Tweets Start -->
      <section class="client-bg">
        <div class="ptb-100">
          <div class="our-tweets">
            <div class="container">
              <div class="row no-gutters">
                <div class="col-12">
                  <div class="heading-part text-center mb-30 mb-sm-20">
                    <h2 class="main_title heading color-white mb-15">Our Latest <span>Tweets</span></h2>
                    <p class="heading-des color-white">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  </div>
                </div>
              </div>
              <div class="row">
                <div id="client" class="owl-carousel client-slider text-center">
                  <div class="item ">
                    <div class="client-detail">
                      <div class="tweet-icon">
                          <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="twitter" class="svg-inline--fa fa-twitter fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512"><path fill="#28a9e2" d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg>
                      </div>
                      <div class="client-inner-detail ">
                        <div class="quote">
                          <p>It is a long established fact that a reader will be <a class="color-white" href="#"># distracted</a> by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters
                          </p>
                        </div>
                        <div class="designation color-white">About 16 days ago</div>
                      </div>
                    </div>
                  </div>
                  <div class="item ">
                    <div class="client-detail">
                      <div class="tweet-icon">
                          <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="twitter" class="svg-inline--fa fa-twitter fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512"><path fill="#28a9e2" d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg>
                      </div>
                      <div class="client-inner-detail ">
                        <div class="quote">
                          <p>It is a long established fact that a reader will be <a class="color-white" href="#"># distracted</a> by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters
                          </p>
                        </div>
                        <div class="designation color-white">About 16 days ago</div>
                      </div>
                    </div>
                  </div>
                  <div class="item ">
                    <div class="client-detail">
                      <div class="tweet-icon">
                          <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="twitter" class="svg-inline--fa fa-twitter fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512"><path fill="#28a9e2" d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg>
                      </div>
                      <div class="client-inner-detail ">
                        <div class="quote">
                          <p>It is a long established fact that a reader will be <a class="color-white" href="#"># distracted</a> by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters
                          </p>
                        </div>
                        <div class="designation color-white">About 16 days ago</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Our Latest Tweets End -->

      <!--Blog Block Start -->
      <section class="ptb-100">
        <div id="blog-section">
          <div class="container">
            <div class="row no-gutters">
              <div class="col-12">
                <div class="heading-part text-center mb-30 mb-sm-20">
                  <h2 class="main_title heading mb-15">Recent <span>Articles</span></h2>
                  <p class="heading-des">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
              </div>
            </div>
            <div class="blog row">
              <div id="blog" class="owl-carousel owl-slider">
        
                <div class="item">
                  <div class="blog-item box-shadow">
                    <div class="blog-media"> 
                      <img src ="<?php echo base_url();?>front_assets/images/blog/blog_img2_md.jpg" style="height:250px" alt="TravelRide">
                      <div class="blog-effect"></div> 
                      <a href="#" title="Click For Read More" class="read">&nbsp;</a>
                    </div>
                    <div class="blog-detail p-25 p-xs-15">
                      <div class="post-info">
                        <ul class="d-flex align-items-center ">
                          <li>
                            <div class="post-date">
                              <span><i class="far fa-calendar-alt"></i></span> Jan 13, 2021
                            </div>
                          </li>
                          <li>
                            <div class="post-user">
                              <a href="#"><span><i class="far fa-user"></i></span> cormon jons</a>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div class="blog-title">
                        <a href="#">Prem Mandir</a>
                      </div>
                      <p class="dec mb-3">Prem Mandir Prem Mandir, 54-acre premises in the outskirts of…</p>
                      <a class="read-more" href="#">Read More <i class="fas fa-chevron-right"></i></a>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="blog-item box-shadow">
                    <div class="blog-media"> 
                      <img src ="<?php echo base_url();?>front_assets/images/blog/blog_img3_md.jpg" style="height:250px" alt="TravelRide">
                      <div class="blog-effect"></div> 
                      <a href="#" title="Click For Read More" class="read">&nbsp;</a>
                    </div>
                    <div class="blog-detail p-25 p-xs-15">
                      <div class="post-info">
                        <ul class="d-flex align-items-center ">
                          <li>
                            <div class="post-date">
                              <span><i class="far fa-calendar-alt"></i></span> Jan 13, 2021
                            </div>
                          </li>
                          <li>
                            <div class="post-user">
                              <a href="#"><span><i class="far fa-user"></i></span> cormon jons</a>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div class="blog-title">
                        <a href="#">Radha Vallabh Temple:</a>
                      </div>
                      <p class="dec mb-3">Radha Vallabh Temple: Experience the tranquillity and spirituality…</p>
                      <a class="read-more" href="#">Read More <i class="fas fa-chevron-right"></i></a>
                    </div>
                  </div>
                </div>
          
                <div class="item">
                  <div class="blog-item box-shadow">
                    <div class="blog-media"> 
                      <img src ="<?php echo base_url();?>front_assets/images/blog/blog_img5_md.jpg" style="height:250px" alt="TravelRide">
                      <div class="blog-effect"></div> 
                      <a href="#" title="Click For Read More" class="read">&nbsp;</a>
                    </div>
                    <div class="blog-detail p-25 p-xs-15">
                      <div class="post-info">
                        <ul class="d-flex align-items-center ">
                          <li>
                            <div class="post-date">
                              <span><i class="far fa-calendar-alt"></i></span> Jan 13, 2021
                            </div>
                          </li>
                          <li>
                            <div class="post-user">
                              <a href="#"><span><i class="far fa-user"></i></span> cormon jons</a>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div class="blog-title">
                        <a href="#">Govind dev</a>
                      </div>
                      <p class="dec mb-3">Govind Dev Temple is one of the most impressive and astonishing…</p>
                      <a class="read-more" href="#">Read More <i class="fas fa-chevron-right"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Blog Block End -->

      <!-- CONTAINER END -->

      <!-- News Letter Start -->
      <div class="newsletter-bg">
        <div class="container">
          <div class="newsletter">
            <div class="newsletter-inner text-center text-lg-left">
              <div class="row justify-content-center align-items-center">
                <div class=" col-xl-10 col-12">
                  <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-6">
                      <div class="d-lg-flex align-items-center">
                        <div class="newsletter-icon"><img src ="<?php echo base_url();?>front_assets/images/subscribe_icon.svg" alt="TravelRide"></div>
                        <div class="newsletter-title color-white">
                          <h2 class="main_title mb-0">Get Updates & More</h2>
                          <p class="m-0">Thoughtful thoughts to your inbox</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                      <form>
                        <div class="newsletter-box">
                          <input type="email" placeholder="Email Here...">
                          <button title="Subscribe" class="btn btn-color">Subscribe</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- News Letter End -->

     

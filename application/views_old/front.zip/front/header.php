<!DOCTYPE html>
 <html lang="en">
  <!--<![endif]-->
  <head>
    <!-- Basic Page Needs
      ================================================== -->
    <meta charset="utf-8">
    <title>Holy Trip Advisor</title>
    <!-- SEO Meta
      ================================================== -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="distribution" content="global">
    <meta name="revisit-after" content="2 Days">
    <meta name="robots" content="ALL">
    <meta name="rating" content="8 YEARS">
    <meta name="Language" content="en-us"> 
    <meta name="GOOGLEBOT" content="NOARCHIVE">

    <!-- Mobile Specific Metas ====================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- =========== CSS =========== -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/responsive.css">

    <!-- =========== fav-icon =========== -->
    <link rel="shortcut icon" href="images/favicon.png">

    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
  </head>
  <body class="homepage">

    <!-- Loader Start -->
    <div class="se-pre-con">
      <div class="spinner">
        <div class="triple-spinner"></div>
      </div>
    </div>
    <!-- Loader End -->

    <div id="current" class="main">
     
      <!-- HEADER START -->
      <header class="navbar navbar-custom header" id="header">
        <div class="navbar-expand">
          <div class="header-top">
            <div class="container">
              <div class="top-line">
                <div class="row align-items-center">
                  <div class="col-sm-6 col-12">
                    <div class="top-left-link float-md-left">
                      <ul class="d-flex align-items-center  justify-content-center">
                        <li style="width:100%;">
                          <div class="select-dropdown language-currency">
                            <div class="drop-option">
                              <div class="drop-list">
                                <span><marquee style="background-color:#000;color:#fff;">** INDIA'S FIRST PILGRIMAGE &amp; DARSHAN SITE ** </marquee></span>
                               
                              </div>
                               
                             </div>
                          </div>
                        </li>
                      
                      </ul>
                    </div>
                  </div>
                  <div class="col-sm-6 col-12">
                    <div class="top-right-link float-sm-right d-none d-sm-block">
                      <ul>
                        <li class="login-icon content">
                          <a href="#" title="Login">
                            <span><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 20 20"><path d="M14.74 15.57h-2.49a.36.36 0 0 1-.36-.36v-1.19a.36.36 0 0 1 .36-.36h2.49a.95.95 0 0 0 .95-.95V7.04a.95.95 0 0 0-.95-.95h-2.49a.36.36 0 0 1-.36-.36V4.55a.36.36 0 0 1 .36-.36h2.49a2.85 2.85 0 0 1 2.85 2.85v5.69c0 1.57-1.28 2.84-2.85 2.84zm-1.39-5.96L8.37 4.63a.72.72 0 0 0-1.22.51v2.85H3.12c-.39 0-.71.32-.71.71v2.85c0 .39.32.71.71.71h4.03v2.85c0 .64.77.95 1.22.5l4.98-4.98c.27-.29.27-.74 0-1.02z" fill="#fff"></path></svg></span> Contact Us
                          </a>
                        </li>
                        <li class="register-icon">
                          <a href="" title="Register">
                            <span><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 20 20"><path d="M9.69 10.46c2.17 0 3.94-1.76 3.94-3.94s-1.76-3.94-3.94-3.94-3.94 1.77-3.94 3.94 1.76 3.94 3.94 3.94zm3.5.87h-1.51a4.75 4.75 0 0 1-1.99.44 4.75 4.75 0 0 1-1.99-.44H6.19c-1.93 0-3.5 1.57-3.5 3.5v.44c0 .72.59 1.31 1.31 1.31h11.38c.72 0 1.31-.59 1.31-1.31v-.44c0-1.93-1.57-3.5-3.5-3.5z" fill="#fff"></path></svg></span> Enquiry Now
                          </a>
                        </li>
                        <li class="gift-icon">
                          <a href="#" title="Gift card">
                            <span><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 20 20"><path d="M17.01 16H7.48v-5.85l1.08 1.63c.15.22.45.29.69.14a.5.5 0 0 0 .14-.69l-.8-1.2c.1.02.2.05.31.05.66 0 1.25-.4 1.47-1.07h8.13v5.5c0 .82-.67 1.49-1.49 1.49zm-1-5h-4.05c-.28 0-.5.22-.5.5s.22.5.5.5h4.05c.28 0 .5-.22.5-.5s-.22-.5-.5-.5zm0 2h-4.05c-.28 0-.5.22-.5.5s.22.5.5.5h4.05c.28 0 .5-.22.5-.5s-.22-.5-.5-.5zM9.47 8.5c0 .46-.51.73-.88.47l-.71-.47.71-.48a.57.57 0 0 1 .79.17.56.56 0 0 1 .09.31zM8.03 7.19l-.55.38V4h9.53c.82 0 1.49.67 1.49 1.5V8h-8.13c-.26-.81-1.14-1.26-1.95-1-.14.05-.27.11-.39.19zM1.5 14.5V9h2.08a1.56 1.56 0 0 0 1.48 1.07 1.06 1.06 0 0 0 .31-.05l-.8 1.2c-.15.23-.09.54.14.7a.5.5 0 0 0 .69-.14l1.08-1.63V16H2.99c-.82 0-1.49-.67-1.49-1.5zm3.87-6.48l.71.48-.71.47c-.38.26-.88-.02-.88-.47 0-.46.5-.73.88-.48zM3.58 8H1.5V5.5c0-.83.67-1.5 1.49-1.5h3.49v3.57l-.56-.38c-.84-.56-2-.19-2.34.81z" fill-rule="evenodd" fill="#fff"></path></svg></span> Gift card
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="header-middle">
            <div class="container">
              <div class="row no-gutters align-items-center">
                <div class="col-lg-9 col-6">
                  <div class="header-middle-left">
                    <div class="row no-gutters align-items-center">
                      <div class="col-lg-3 col-12">
                        <div class="logo navbar-header float-none-sm">
                          <a class="navbar-brand page-scroll" href="<?php echo base_url();?>">
                            <img alt="Holy Trip Advisor" src ="<?php echo base_url();?>front_assets/images/logo.png">
                          </a> 
                        </div>
                      </div>
                      <div class="col-lg-9 col-0">
                        <div class="overlay"></div>
                        <div id="menu" class="navbar-collapse collapse justify-content-center">
                          <div class="top-right-link  mobile-link d-block d-sm-none">
                            <ul>
                              <li class="login-icon content">
                                <a href="#" title="Login">
                                  <span><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 20 20"><path d="M14.74 15.57h-2.49a.36.36 0 0 1-.36-.36v-1.19a.36.36 0 0 1 .36-.36h2.49a.95.95 0 0 0 .95-.95V7.04a.95.95 0 0 0-.95-.95h-2.49a.36.36 0 0 1-.36-.36V4.55a.36.36 0 0 1 .36-.36h2.49a2.85 2.85 0 0 1 2.85 2.85v5.69c0 1.57-1.28 2.84-2.85 2.84zm-1.39-5.96L8.37 4.63a.72.72 0 0 0-1.22.51v2.85H3.12c-.39 0-.71.32-.71.71v2.85c0 .39.32.71.71.71h4.03v2.85c0 .64.77.95 1.22.5l4.98-4.98c.27-.29.27-.74 0-1.02z" fill="#fff"></path></svg></span> Contact Us
                                </a>
                              </li>
                              <li class="register-icon">
                                <a href="" title="Register">
                                  <span><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 20 20"><path d="M9.69 10.46c2.17 0 3.94-1.76 3.94-3.94s-1.76-3.94-3.94-3.94-3.94 1.77-3.94 3.94 1.76 3.94 3.94 3.94zm3.5.87h-1.51a4.75 4.75 0 0 1-1.99.44 4.75 4.75 0 0 1-1.99-.44H6.19c-1.93 0-3.5 1.57-3.5 3.5v.44c0 .72.59 1.31 1.31 1.31h11.38c.72 0 1.31-.59 1.31-1.31v-.44c0-1.93-1.57-3.5-3.5-3.5z" fill="#fff"></path></svg></span> Enquiry Now
                                </a>
                              </li>
                              <li class="gift-icon">
                                <a href="#" title="Gift card">
                                  <span><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 20 20"><path d="M17.01 16H7.48v-5.85l1.08 1.63c.15.22.45.29.69.14a.5.5 0 0 0 .14-.69l-.8-1.2c.1.02.2.05.31.05.66 0 1.25-.4 1.47-1.07h8.13v5.5c0 .82-.67 1.49-1.49 1.49zm-1-5h-4.05c-.28 0-.5.22-.5.5s.22.5.5.5h4.05c.28 0 .5-.22.5-.5s-.22-.5-.5-.5zm0 2h-4.05c-.28 0-.5.22-.5.5s.22.5.5.5h4.05c.28 0 .5-.22.5-.5s-.22-.5-.5-.5zM9.47 8.5c0 .46-.51.73-.88.47l-.71-.47.71-.48a.57.57 0 0 1 .79.17.56.56 0 0 1 .09.31zM8.03 7.19l-.55.38V4h9.53c.82 0 1.49.67 1.49 1.5V8h-8.13c-.26-.81-1.14-1.26-1.95-1-.14.05-.27.11-.39.19zM1.5 14.5V9h2.08a1.56 1.56 0 0 0 1.48 1.07 1.06 1.06 0 0 0 .31-.05l-.8 1.2c-.15.23-.09.54.14.7a.5.5 0 0 0 .69-.14l1.08-1.63V16H2.99c-.82 0-1.49-.67-1.49-1.5zm3.87-6.48l.71.48-.71.47c-.38.26-.88-.02-.88-.47 0-.46.5-.73.88-.48zM3.58 8H1.5V5.5c0-.83.67-1.5 1.49-1.5h3.49v3.57l-.56-.38c-.84-.56-2-.19-2.34.81z" fill-rule="evenodd" fill="#fff"></path></svg></span> Gift card
                                </a>
                              </li>
                            </ul>
                          </div>
                          <ul id="menu-main" class="nav navbar-nav">
                            <li class="level"> <a class="page-scroll" href="<?php echo base_url();?>">Home</a>  </li>
					 <li class="level"> <a class="page-scroll" href="<?php echo base_url();?>">Hotel</a>  </li>
					 <li class="level"> <a class="page-scroll" href="https://jsdl.in/DT-99MZJJWJNB6">Car</a>  </li>
					 <li class="level"> <a class="page-scroll" href="<?php echo base_url();?>">Tour</a>  </li>
					 <li class="level"> <a class="page-scroll" href="<?php echo base_url();?>">Katha</a></li>
					 <li class="level"> <a class="page-scroll" href="<?php echo base_url();?>">Online Pooja</a></li>
					 <li class="level"> <a class="page-scroll" href="<?php echo base_url();?>">Place to Go</a></li>
                     
							
							
                              </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
				
 
				
                <div class="col-lg-3 col-6">
                  <div class="header-middle-right">
                    <div class="header-contact-info d-none d-lg-block">
                      <span><i class="fas fa-phone-alt"></i></span>
                      <h3>+91-8630658592</h3>
                      <p class="m-0">Toll Free & 24/7 Available</p>
                    </div>
                    <div class="right-side header-right-link">
                      <ul>
                        <li class="side-toggle">
                          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"><i class="fas fa-bars"></i></button>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
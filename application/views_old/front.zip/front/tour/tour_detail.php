      <!-- Bread Crumb STRAT -->
      <section class="bread bread-banner">
        <div class="container">
          <div class="bread-detail text-center d-md-flex align-items-center justify-content-between">
            <h4 class="bread-title mb-3 mb-md-0"><?php echo $dataview[0]->title?></h4>
            <div class="bread-crumb">
              <ul>
                <li class="breadcrumb-item"><a href="<?php echo base_url();?>"><i class="fa fa-home"></i> Home</a></li>
                <li class="breadcrumb-item"><a href="#">Hotels</a></li>
                <li class="breadcrumb-item active"><a href="#"><?php echo $dataview[0]->title?></a></li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <!-- Bread Crumb END --> 

      <!--package Block Start -->
      <section class="ptb-100 tour-detail">
        <div class="container">
          <div class="row">
            <div class="col-lg-8">
              <div class="tour-item">
                <div class="detail-title">
                  <h2><?php echo $dataview[0]->title?></h2>
                </div>
                <div class="tour-rating mb-3">
                  <ul>
                    <li>
                      <button type="button" class="rating-star" data-toggle="modal" data-target="#star-btn">
                        <i class="fa fa-star" aria-hidden="true"></i> <span><?php echo $dataview[0]->star?></span>
                      </button>
                    </li>
                    <li><a href="#review" class="page-scroll">Reviews</a></li>
                   </ul>
                </div>
                <div class="tour-info pb-4">
                  <ul class="list-meta d-flex mb-0">  
                    <li class="mr-2 mr-md-4">
                      <div class="places"><a href="#"><span><i class="fas fa-map-marker-alt"></i></span> <?php  $cname = $dataview[0]->location_id;
				$sqll= "SELECT * FROM location WHERE id='$cname'"; 
                $sql = $this->db->query($sqll);
                $query= $sql->result();
                 if(isset($query[0]->city)) {
                  echo $query[0]->city;
                   }
						   ?> </a></div>
                    </li> 
                     
                  </ul>
                </div>
                <div class="single-content-item ptb-25">
                  <div class="row">
                    <div class="col-lg-6 col-6">
                      <div class="single-tour-feature d-flex align-items-center mb-3">
                        <div class="single-feature-icon icon-element ml-0 flex-shrink-0">
                          <span class="icon"><i class="fas fa-hotel"></i></span>
                        </div>
                        <div class="single-feature-titles">
                          <h5 class="title mb-1">Tour Type</h5>
                          <span class="font-size-13"><?php echo $dataview[0]->tourtype;?></span>
                        </div>
                      </div>
                    </div>
					
					
					<div class="col-lg-6 col-6">
                      <div class="single-tour-feature d-flex align-items-center mb-3">
                        <div class="single-feature-icon icon-element ml-0 flex-shrink-0">
                          <span class="icon"><i class="far fa-clock"></i></span>
                        </div>
                        <div class="single-feature-titles">
                          <h5 class="title mb-1">Duration</h5>
                          <span class="font-size-13"><?php echo $dataview[0]->duration;?></span>
                        </div>
                      </div>
                    </div>
					
                 
                  
                   
                
                    <div class="col-lg-6 col-6">
                      <div class="single-tour-feature d-flex align-items-center mb-3">
                        <div class="single-feature-icon icon-element ml-0 flex-shrink-0">
                          <span class="icon"><i class="fas fa-map"></i></span>
                        </div>
                        <div class="single-feature-titles">
                          <h5 class="title mb-1">City</h5>
                          <span class="font-size-13"> 
				<?php  $cname = $dataview[0]->location_id;
				$sqll= "SELECT * FROM location WHERE id='$cname'"; 
                $sql = $this->db->query($sqll);
                $query= $sql->result();
                 if(isset($query[0]->city)) {
                  echo $query[0]->city;
                   }
						   ?> </span>
                        </div>
                      </div>
                    </div>
					
					    <div class="col-lg-6 col-6">
                      <div class="single-tour-feature d-flex align-items-center mb-3">
                        <div class="single-feature-icon icon-element ml-0 flex-shrink-0">
                          <span class="icon"><i class="fas fa-globe-americas"></i></span>
                        </div>
                        <div class="single-feature-titles">
                          <h5 class="title mb-1">Country</h5>
                          <span class="font-size-13">INDIA</span>
                        </div>
                      </div>
                    </div>
                
                  </div>
                </div>
                <div class="fotorama" data-nav="thumbs" data-allowfullscreen="native"> 
				  	<?php foreach(json_decode($dataview[0]->gallery) as $img): ?>	
                  <a href="#"><img src="<?php echo base_url();?>upload_images/<?php echo $img?>" alt="<?php echo $dataview[0]->title;?>"></a>

<?php endforeach; ?>	

												 
                  
                </div>
              </div>
              <div class="tour-detail-tab mt-60">
                <ul class="nav nav-tabs  mb-30" id="tab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link btn active" id="description_tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">Overview</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link btn" id="amenities_tab" data-toggle="tab" href="#amenities" role="tab" aria-controls="amenities" aria-selected="false">Itinerary</a>
                  </li>
				  
				  <li class="nav-item">
                    <a class="nav-link btn" id="inclusion" data-toggle="tab" href="#inclusion" role="tab" aria-controls="amenities" aria-selected="false">inclusion</a>
                  </li>
				  
				  <li class="nav-item">
                    <a class="nav-link btn" id="exclusion" data-toggle="tab" href="#exclusion" role="tab" aria-controls="amenities" aria-selected="false">exclusion</a>
                  </li>
                
                </ul>
                <div class="tab-content" id="tab_content">
 <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description_tab">
                    <div class="description">
					 <?php echo $dataview[0]->overview;?>
                      
                    </div>
                  </div>
                  <div class="tab-pane fade" id="amenities" role="tabpanel" aria-labelledby="amenities_tab">
                     <div class="description">
					 <?php echo $dataview[0]->itinerary;?>
                      
                    </div>
                  </div>
				  
                    <div class="tab-pane fade" id="inclusion" role="tabpanel" aria-labelledby="inclusion">
                     <div class="description">
					 <?php echo $dataview[0]->inclusion;?>
                      
                    </div>
                  </div>
                    <div class="tab-pane fade" id="exclusion" role="tabpanel" aria-labelledby="exclusion">
                     <div class="description">
					 <?php echo $dataview[0]->exclusion;?>
                      
                    </div>
                  </div>
                   
                </div>
              </div>
       
              <div class="tour-map mt-60">
                <div class="row">
                  <div class="col-12">
                    <h3 class="sub-heading mb-30 mb-xs-15">Location</h3>
                    <div class="maps">
                     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d56637.33411221604!2d77.64913510428201!3d27.474446121109462!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x397371163d4d5205%3A0x4273a09defe10ea5!2sMathura%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1643638937970!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                  </div>
                </div>
              </div>
            
               <div id="write_review" class="main-form mt-60">
                <h3 class="sub-heading mb-30 mb-xs-15">Write a review</h3>
                <div class="rate-option">
                  <div class="row">
                    <div class="col-md-4 col-6">
                      <div class="star-rating mb-2">
                        <label>Service</label>
                        <fieldset>
                          <input type="checkbox" id="ser5" name="rating" value="5"><label for="ser5" title="Outstanding"></label>
                          <input type="checkbox" id="ser4" name="rating" value="4"><label for="ser4" title="Very Good"></label>
                          <input type="checkbox" id="ser3" name="rating" value="3"><label for="ser3" title="Good"></label>
                          <input type="checkbox" id="ser2" name="rating" value="2"><label for="ser2" title="Poor"></label>
                          <input type="checkbox" id="ser1" name="rating" value="1"><label for="ser1" title="Very Poor"></label>
                        </fieldset>
                      </div>
                    </div>
                    <div class="col-md-4 col-6">
                      <div class="star-rating mb-2">
                        <label>Location</label>
                        <fieldset>
                          <input type="checkbox" id="loc5" name="rating" value="5"><label for="loc5" title="Outstanding"></label>
                          <input type="checkbox" id="loc4" name="rating" value="4"><label for="loc4" title="Very Good"></label>
                          <input type="checkbox" id="loc3" name="rating" value="3"><label for="loc3" title="Good"></label>
                          <input type="checkbox" id="loc2" name="rating" value="2"><label for="loc2" title="Poor"></label>
                          <input type="checkbox" id="loc1" name="rating" value="1"><label for="loc1" title="Very Poor"></label>
                        </fieldset>
                      </div>
                    </div>
                    <div class="col-md-4 col-6">
                      <div class="star-rating mb-2">
                        <label>Comfort</label>
                        <fieldset>
                          <input type="checkbox" id="com5" name="rating" value="5"><label for="com5" title="Outstanding"></label>
                          <input type="checkbox" id="com4" name="rating" value="4"><label for="com4" title="Very Good"></label>
                          <input type="checkbox" id="com3" name="rating" value="3"><label for="com3" title="Good"></label>
                          <input type="checkbox" id="com2" name="rating" value="2"><label for="com2" title="Poor"></label>
                          <input type="checkbox" id="com1" name="rating" value="1"><label for="com1" title="Very Poor"></label>
                        </fieldset>
                      </div>
                    </div>
                    <div class="col-md-4 col-6">
                      <div class="star-rating mb-2">
                        <label>Cleanliness</label>
                        <fieldset>
                          <input type="checkbox" id="cln5" name="rating" value="5"><label for="cln5" title="Outstanding"></label>
                          <input type="checkbox" id="cln4" name="rating" value="4"><label for="cln4" title="Very Good"></label>
                          <input type="checkbox" id="cln3" name="rating" value="3"><label for="cln3" title="Good"></label>
                          <input type="checkbox" id="cln2" name="rating" value="2"><label for="cln2" title="Poor"></label>
                          <input type="checkbox" id="cln1" name="rating" value="1"><label for="cln1" title="Very Poor"></label>
                        </fieldset>
                      </div>
                    </div>
                    <div class="col-md-4 col-6">
                      <div class="star-rating mb-2">
                        <label>Facilities</label>
                        <fieldset>
                          <input type="checkbox" id="f5" name="rating" value="5"><label for="f5" title="Outstanding"></label>
                          <input type="checkbox" id="f4" name="rating" value="4"><label for="f4" title="Very Good"></label>
                          <input type="checkbox" id="f3" name="rating" value="3"><label for="f3" title="Good"></label>
                          <input type="checkbox" id="f2" name="rating" value="2"><label for="f2" title="Poor"></label>
                          <input type="checkbox" id="f1" name="rating" value="1"><label for="f1" title="Very Poor"></label>
                        </fieldset>
                      </div>
                    </div>
                  </div>
                </div>
                <form>
                  <div class="row mt-30 mt-xs-15">
                    <div class="col-lg-6 col-12 mb-30 mb-xs-15">
                      <input type="text" placeholder="Name" required="">
                    </div>
                    <div class="col-lg-6 col-12 mb-30 mb-xs-15">
                      <input type="email" placeholder="Email" required="">
                    </div>
                    <div class="col-12 mb-30 mb-xs-15">
                      <textarea cols="30" rows="4" placeholder="Message" required=""></textarea>
                    </div>
                    <div class="col-12 mb-30 mb-xs-15">
                      <div class="star-rating">
                        <label class="float-left">Overall  Rating :</label>
                        <fieldset>
                          <input type="checkbox" id="star5" name="rating" value="5"><label for="star5" data-toggle="tooltip" data-placement="top" title="Outstanding"></label>
                          <input type="checkbox" id="star4" name="rating" value="4"><label for="star4" title="Very Good"></label>
                          <input type="checkbox" id="star3" name="rating" value="3"><label for="star3" title="Good"></label>
                          <input type="checkbox" id="star2" name="rating" value="2"><label for="star2" title="Poor"></label>
                          <input type="checkbox" id="star1" name="rating" value="1"><label for="star1" title="Very Poor"></label>
                        </fieldset>
                      </div>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-color" name="submit" type="submit">Submit a Review</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="sidebar-block sidebar-block-1 pt-sm-60 mt-md-30">
                <div class="box-shadow radius-5px p-25 p-xs-15">
                  <div class="sidebar-box listing-box"> <span class="opener plus"></span>
                    <div class="sidebar-title">
                      <h3><span>Tour Booking</span></h3>
                    </div>
                    <div class="sidebar-contant pt-4">
                      <div class=" main-form tour-search-detail">
                       <!-- <div class="price-box d-flex align-items-center mb-3"> 
                          <span class="mr-1">From</span>
                          <h3 class="price mr-1 mb-0">$89.00</h3> 
                          <del class="old-price">$120.00</del> 
                        </div>-->
                        <form class="main-form" action="<?php echo base_url();?>home/tour_booking/<?php echo $dataview[0]->id;?>" method="get">
						<input type="hidden" value="<?php echo $dataview[0]->id;?>" name="hotel_id" >
                          <div class="sidebar-date">
                            <div class="form-group">
                              <div class="input-inner mb-3 mb-xl-0">
                                <label for="datepicker-start">Booking Date</label>
                                <div class="input-box">
                                  <div class="input-icon">
                                    <span><i class="far fa-calendar-alt"></i></span>
                                  </div>
                                  <input id="datepicker-start" name="tour_booking_date" class="form-control datepicker datepick" type="text" required="" placeholder="MM/DD/YY">
                                </div>
                              </div>
                            </div>
                   
                 
                            </div>
                          </div>
                          <div class="sidebar-guest">
                            <div class="qty-box mb-2 d-flex align-items-center justify-content-between">
                              <label class="">Adults <span>Age 18+</span></label>
                              <div class="product-qty ">
                                <div class="custom-qty">
                                  <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button">  </button>
                                  <input  type="text"  class="input-text qty" title="Qty" value="1" maxlength="8" id="qty" name="adults">
                                  <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button">  </button>
                                </div>
                              </div>
                            </div>
                            <div class="qty-box mb-2 d-flex align-items-center justify-content-between">
                              <label class="">Children <span>5-17 years old</span></label>
                              <div class="product-qty ">
                                <div class="custom-qty">
                                  <button onclick="var result = document.getElementById('qty2'); var qty2 = result.value; if( !isNaN( qty2 ) &amp;&amp; qty2 &gt; 1 ) result.value--;return false;" class="reduced items" type="button">  </button>
                                  <input type="text" class="input-text qty" title="Qty" value="1" maxlength="8" id="qty2" name="children">
                                  <button onclick="var result = document.getElementById('qty2'); var qty2 = result.value; if( !isNaN( qty2 )) result.value++;return false;" class="increase items" type="button">  </button>
                                </div>
                              </div>
                            </div>
                            <div class="qty-box mb-2 d-flex align-items-center justify-content-between">
                              <label class="">Infants <span>0-2 years old</span></label>
                              <div class="product-qty ">
                                <div class="custom-qty">
                                  <button onclick="var result = document.getElementById('qty3'); var qty3 = result.value; if( !isNaN( qty3 ) &amp;&amp; qty3 &gt; 1 ) result.value--;return false;" class="reduced items" type="button">  </button>
                                  <input type="text" class="input-text qty" title="Qty" value="1" maxlength="8" id="qty3" name="infants">
                                  <button onclick="var result = document.getElementById('qty3'); var qty3 = result.value; if( !isNaN( qty3 )) result.value++;return false;" class="increase items" type="button">  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="tour-booking-btn pt-3">
                            <button type="submit" class="btn btn-color w-100 mb-3">Book Now</button>
                           
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                 <div class="sidebar-box"> <span class="opener plus"></span>
                    <div class="sidebar-title">
                      <h3><span>Need Help</span></h3>
                    </div>
                    <div class="sidebar-contant pt-3">
                      <div class="support-service p-25 p-xs-15">
                        <span><i class="fas fa-phone-alt"></i></span>
                        <h3>+91-8630658592</h3>
                        <p class="m-0">Toll Free & 24/7 Available</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--package Block End -->

      <!-- Product Rating popup Start -->
      <div id="star-btn" class="modal fade" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h2 class="section_title heading m-0">Reviews</h2>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="reviews-reting">
                <div class="reting-detail  d-flex align-items-center">
                  <h3 class="sub-heading"><span>25</span> Reviews</h3>
                  <div class="rating-summary-block">
                    <div class="rating-result" title="88%"> <span style="width:88%"></span> </div>
                  </div>
                  <span class="text-heading"> 4.5 out of 5</span>
                </div>
                <div class="reting-progress">
                  <div class="progress-detail star-5 d-flex align-items-center">
                    <div class="progress-star bg-success d-flex align-items-center">
                      <span class="star-num">5</span> 
                      <i class="far fa-star"></i>
                    </div>
                    <div class="w-100">
                      <div class="progress mx-auto mx-md-0">
                        <div class="progress-bar bg-success" style="width:90%" role="progressbar"></div>
                      </div>
                    </div>
                    <span class="ret-num">9</span>
                  </div>
                </div>
                <div class="reting-progress mt-3">
                  <div class="progress-detail star-4 d-flex align-items-center">
                    <div class="progress-star bg-info d-flex align-items-center">
                      <span class="star-num">4</span> 
                      <i class="far fa-star"></i>
                    </div>
                    <div class="w-100">
                      <div class="progress mx-auto mx-md-0">
                        <div class="progress-bar bg-info" style="width:60%" role="progressbar"></div>
                      </div>
                    </div>
                    <span class="ret-num">6</span>
                  </div>
                </div>
                <div class="reting-progress mt-3">
                  <div class="progress-detail star-3 d-flex align-items-center">
                    <div class="progress-star bg-primary d-flex align-items-center">
                      <span class="star-num">3</span> 
                      <i class="far fa-star"></i>
                    </div>
                    <div class="w-100">
                      <div class="progress mx-auto mx-md-0">
                        <div class="progress-bar bg-primary" style="width:40%" role="progressbar"></div>
                      </div>
                    </div>
                    <span class="ret-num">4</span>
                  </div>
                </div>
                <div class="reting-progress mt-3">
                  <div class="progress-detail star-2 d-flex align-items-center">
                    <div class="progress-star bg-warning d-flex align-items-center">
                      <span class="star-num">2</span> 
                      <i class="far fa-star"></i>
                    </div>
                    <div class="w-100">
                      <div class="progress mx-auto mx-md-0">
                        <div class="progress-bar bg-warning" style="width:30%" role="progressbar"></div>
                      </div>
                    </div>
                    <span class="ret-num">3</span>
                  </div>
                </div>
                <div class="reting-progress mt-3">
                  <div class="progress-detail star-1 d-flex align-items-center">
                    <div class="progress-star bg-danger d-flex align-items-center">
                      <span class="star-num">1</span> 
                      <i class="far fa-star"></i>
                    </div>
                    <div class="w-100">
                      <div class="progress mx-auto mx-md-0">
                        <div class="progress-bar bg-danger" style="width:30%" role="progressbar"></div>
                      </div>
                    </div>
                    <span class="ret-num">3</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
      <!-- Product Rating popup End -->

      <!-- Related Hotels Packages Start -->
      <section class="pb-100">
        <div class="container">
          <div class="row no-gutters">
            <div class="col-12">
              <div class="heading-part text-center mb-30 mb-sm-20">
                <h2 class="main_title heading mb-15">Related <span>Hotels</span></h2>
                <p class="heading-des">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
              </div>
            </div>
          </div>
          <div class="row">
            <div id="packages-part" class="packages-part owl-carousel">
			
			
             
			           <?php foreach($related_hotel as $view) { ?>
			  <div class="item"> 
                <div class="card packages-box box-shadow overflow-hidden">
                  <div class="package-img position-relative">
                    <a href="#">
<img alt="TravelRide" src ="<?php echo base_url();?>/upload_images/<?php echo $view->thumb_image;?>" style="height:300px;">
                      <div class="effect"></div>
                    </a>
                    <div class="price-box position-absolute mt-2"> 
                      <div class=" d-flex align-items-center">
                        <div class="price mb-0">$89</div> 
                        <div class="price-text mb-0 ml-2">/ Night</div> 
                      </div>
                    </div>
                  </div>
                  <div class="card-body p-25 p-xs-15">
                    <div class="packages-details">
                      <h4><a href="#" class="title"><?php echo $view->title;?>, 
					  <?php  $cname = $view->location_id;
								$sqll= "SELECT * FROM location WHERE id='$cname'"; 
                                            $sql = $this->db->query($sqll);
                                            $query= $sql->result();
                                            if(isset($query[0]->city)) {
                                                echo $query[0]->city;
                                            }
						   ?></a></h4>
                      <div class="mt-2">  
                        <ul>
                          <li>
                            <div class="places"><span class="icon"><i class="fas fa-map-marker-alt"></i></span> 
							<?php echo $view->address;?> </div>
                          </li>
                        </ul> 
                      </div>
                      <p class="my-2"><?php echo substr(strip_tags($view->overview),0, 50);?> </p>
                      <div class="rating-summary-block">
                        <div class="rating-result" title="70%"> <span style="width:<?php echo $view->star*20;?>%"></span> </div>
                        <span class="label-review"><?php echo $view->star;?> Rating</span>
                      </div>
                      <div class="packages-btn mt-30 mt-xs-20">
                        <a class="btn btn-color mr-3" href="#">Book Now</a>
                        <a class="btn btn-light" href="<?php echo base_url();?>home/hotel_detail/<?php echo $view->id;?>">View Detail</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            
			    <?php } ?>
              

		   </div>
          </div>
        </div>
      </section>
      <!-- Related Hotels Packages End -->
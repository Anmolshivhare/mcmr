<div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">Location</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                                            <li class="breadcrumb-item active">Dashboard</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                    

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Add Location</h4>

                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="mt-4">
                                                
         <form method="post" action="<?php echo base_url();?>adminlocation/edit/<?php echo $update[0]->id?>" enctype="multipart/form-data">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">city</label>
                                                            <input type="text" name="city" value="<?php echo $update[0]->city?>" class="form-control" id="formrow-firstname-input">
                                                        </div>
            
                                                        <div class="row">                                                            
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-email-input">longitude</label>
                                                                    <input type="text" value="<?php echo $update[0]->longitude?>"  class="form-control" name="longitude" id="formrow-email-input">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-password-input">latitude</label>
                                                                    <input type="text" value="<?php echo $update[0]->latitude?>"  class="form-control" name="latitude" id="formrow-password-input">
                                                                </div>
                                                            </div>
                                                        </div>
														
														   <div class="row">                                                            
                                                            <div class="col-md-6">
                                                             <div class="mb-3">
                                                                    <label class="form-label" for="formrow-email-input">Image</label>
                                                                    <input type="file" name="image" class="form-control" id="formrow-email-input">
																	
																	<img src="<?php echo base_url(); ?>upload_images/<?php echo $update[0]->image;?>" alt="" class="rounded avatar-sm">
																	
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-password-input">Status</label>
                                                <select class="form-select" name="status">
												
												  <option value="<?php echo $update[0]->status;?>"><?php echo ($update[0]->status=='1')? 'Enable':'Disabled';?></option>
                                                    <option value="1">Enable</option>
                                                    <option value="0">Disable</option>
                                                </select>
												
												
                                                                </div>
                                                            </div>
                                                        </div>


                                                      
                                                        
                                                        <div class="mt-4">
                                                            <button type="submit" class="btn btn-primary w-md">Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Form Layout -->

                         
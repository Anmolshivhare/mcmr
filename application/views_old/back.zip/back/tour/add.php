	<div class="page-content">
                    <div class="container-fluid">
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0"><?php echo $title;?></h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a  class="btn btn-success btn-rounded waves-effect waves-light" href="<?php echo base_url();?>admintour/index">List</a></li>
                                              
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                    

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Add <?php echo $title;?></h4>

                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="mt-4">
                                                
                                                    <form method="post" action="<?php echo base_url();?>admintour/add" enctype="multipart/form-data">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">Tour Package</label>
                                                           <input type="text" class="form-control" id="" name="title" required>
                                                        </div>
            
                                                        <div class="row">                                                            
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-email-input">Tour Type</label>
														<select class="form-control" name="tourtype">
														 <option value="Sightseeing">Sightseeing</option>
															<option value="One Day Tour">One Day Tour</option>
															<option value="Holydays">Holydays</option>
 															 
														 </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-password-input">Rating Star</label>
                                                                    <select class="form-control" name="star">
																	<option value="1">1</option>
																	<option value="2">2</option>
																	<option value="3">3</option>
																	<option value="4">4</option>
																	<option value="5">5</option>
																	</select>
                                                                </div>
                                                            </div>
                                                        </div>
														
														 
														
														
														
														   <div class="row">                                                            
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-email-input">Image</label>
                                                                    <input type="file" name="image" class="form-control" name="thumb_image" id="formrow-email-input">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-password-input">Select Gallery</label>
                                               <input type="file" class="form-control" name="userFiles[]" multiple/>
                                                                </div>
                                                            </div>
                                                        </div>



													
                                                            
                                                        </div>



														<div class="row">                                                            
                                                   
												   <div class="col-md-3">
														<div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">Duration</label>
                                                           <input type="text" class="form-control" id="" name="duration" >
                                                        </div>
                                                        </div>
														 <div class="col-md-3">
														<div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">occupancy</label>
                                                           <input type="text" class="form-control" id="" name="occupancy" >
                                                        </div>
                                                        </div>
														
														<div class="col-md-6">
														<div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">City</label>
                                                           <select class="form-control" name="location_id">
														   <?php $data=$this->Adminmodel->select('location'); 
															foreach ($data as $dataview) { ?>
													 
															
														 
															<option value="<?php echo $dataview->id;?>"><?php echo $dataview->city;?></option>
															<?php } ?>
															</select>										  
														  
                                                        </div>
                                                        </div>
														
														 
                                                        </div>
														
														
														
													<div class="row">                                                            
                                                    <div class="col-md-12">
                                                     <div class="mb-3">
													   <label class="form-label" for="formrow-password-input">Overview</label>
                                                       <textarea name="overview" class="classic-editor"></textarea>
                                                          </div>
														  </div>
														  </div>
														  
														  <div class="row">                                                            
                                                    <div class="col-md-12">
                                                     <div class="mb-3">
													   <label class="form-label" for="formrow-password-input">itinerary</label>
                                                       <textarea name="itinerary" class="classic-editor2"></textarea>
                                                          </div>
														  </div>
														  </div>
														  
														   <div class="row">                                                            
                                                    <div class="col-md-12">
                                                     <div class="mb-3">
													   <label class="form-label" for="formrow-password-input">Inclusion</label>
                                                       <textarea name="inclusion" class="classic-editor3"></textarea>
                                                          </div>
														  </div>
														  </div>
														  
														  
														    <div class="row">                                                            
                                                    <div class="col-md-12">
                                                     <div class="mb-3">
													   <label class="form-label" for="formrow-password-input">exclusion</label>
                                                       <textarea name="exclusion" class="classic-editor4"></textarea>
                                                          </div>
														  </div>
														  </div>
														  
                                                         
														  
                                                         
															
															
													
														
														<div class="row">                                                            
                                                   
												   <div class="col-md-12">
														<div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">Meta Title</label>
                                                           <input type="text" class="form-control" id="" name="meta_title" >
                                                        </div>
                                                        </div>
														
												   <div class="col-md-12">
														<div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">Meta Description</label>
                                                           <input type="text" class="form-control" id="" name="meta_description" >
                                                        </div>
                                                        </div>
														
														  <div class="col-md-12">
														<div class="mb-3">
                                                            <label class="form-label" for="formrow-firstname-input">Meta Keyword</label>
                                                           <input type="text" class="form-control" id="" name="meta_keyword" >
                                                        </div>
                                                        </div>
														
														
														 
                                                        </div>
															  <div class="row">  
														<div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-password-input">Status</label>
                                                <select class="form-select" name="status">
                                                    <option value="1">Enable</option>
                                                    <option value="0">Disable</option>
                                                </select>
                                                                </div>
                                                            </div>
															
															
															<div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="formrow-password-input">Feature</label>
                                                <select class="form-select" name="feature">
                                                    <option value="1">Enable</option>
                                                    <option value="0">Disable</option>
                                                </select>
                                                                </div>
                                                            </div>
															
															
                                                            </div>
                                                        <div class="mt-4">
                                                            <button type="submit" class="btn btn-primary w-md">Submit</button>
                                                        </div>
														
                                                    </form>
                                                </div>
                                            </div>
                                            </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Form Layout -->

                         
						   <!-- ckeditor -->
        <script src="<?php echo base_url();?>admin_assets//libs/@ckeditor/ckeditor5-build-classic/build/ckeditor.js"></script>

        <!--tinymce js-->
        <script src="<?php echo base_url();?>admin_assets//libs/tinymce/tinymce.min.js"></script>

<script>
        ClassicEditor
        .create( document.querySelector( '.classic-editor' ) )
        .catch( error => {
            console.error( error );
        } );
        </script>
		
		<script>
        ClassicEditor
        .create( document.querySelector( '.classic-editor2' ) )
     
        .catch( error => {
            console.error( error );
        } );
        </script>
		<script>
        ClassicEditor
        .create( document.querySelector( '.classic-editor3' ) )
     
        .catch( error => {
            console.error( error );
        } );
        </script>
		<script>
        ClassicEditor
        .create( document.querySelector( '.classic-editor4' ) )
     
        .catch( error => {
            console.error( error );
        } );
        </script>
        <!-- init js -->
        <script src="<?php echo base_url();?>admin_assets//js/pages/form-editor.init.js"></script>